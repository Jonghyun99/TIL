package co.flearner.destini

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
