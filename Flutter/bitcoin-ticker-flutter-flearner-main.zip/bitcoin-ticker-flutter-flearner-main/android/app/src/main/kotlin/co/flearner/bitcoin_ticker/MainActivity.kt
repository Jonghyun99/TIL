package co.flearner.bitcoin_ticker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
