package co.flearner.quizzler_flutter_flearner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
