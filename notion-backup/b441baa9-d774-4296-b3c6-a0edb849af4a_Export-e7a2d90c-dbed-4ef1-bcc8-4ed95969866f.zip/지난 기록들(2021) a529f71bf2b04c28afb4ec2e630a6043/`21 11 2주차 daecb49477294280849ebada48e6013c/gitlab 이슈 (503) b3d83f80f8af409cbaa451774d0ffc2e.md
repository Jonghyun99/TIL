# gitlab 이슈 (503)

상태: 완료 🙌
작성일시: 2021년 11월 12일 오전 10:41

git proxy setting 문제였음,

git proxy unset으로 해결