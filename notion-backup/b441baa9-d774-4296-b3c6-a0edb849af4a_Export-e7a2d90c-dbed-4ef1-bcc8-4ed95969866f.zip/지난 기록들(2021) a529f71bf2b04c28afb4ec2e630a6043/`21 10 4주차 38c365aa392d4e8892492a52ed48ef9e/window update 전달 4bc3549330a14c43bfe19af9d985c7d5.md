# window update 전달

상태: 완료 🙌
작성일시: 2021년 10월 26일 오전 9:14

본부장님 파일 병합(어드민) → Powershell update → 설정 → 윈도우 업데이트