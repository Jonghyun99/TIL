# PPT4주차 (http에 대해)

상태: 해야할 일
작성일시: 2021년 7월 19일 오전 8:09

http 소켓통신

소켓 통신 3계층 (IP) 4계층(TCP = PORT) 통신

HTTP 통신 : 프로토콜 통신 (7계층 통신, 4계층을 이용하여 통신함)

tcp/ip의 옵션 → http통신

SOAP통신(xml을 주고받음, http를 사용함)

소켓과 http는 통신하는 레이어가 다른 차이가 있음

peer to pper

참고할만한 글 :[https://hwan-shell.tistory.com/271](https://hwan-shell.tistory.com/271)