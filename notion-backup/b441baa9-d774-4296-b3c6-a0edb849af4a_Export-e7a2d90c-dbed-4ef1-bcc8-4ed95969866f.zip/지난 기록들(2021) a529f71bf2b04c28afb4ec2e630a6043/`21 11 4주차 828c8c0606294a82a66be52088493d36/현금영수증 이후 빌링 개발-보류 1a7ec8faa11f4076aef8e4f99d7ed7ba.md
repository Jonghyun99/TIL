# 현금영수증 이후 빌링 개발-보류

상태: 완료 🙌
작성일시: 2021년 11월 22일 오후 3:33

[https://docs.payple.kr/card/pay/outline](https://docs.payple.kr/card/pay/outline)